#include <stdio.h>
#include <locale.h>

void homework()
{
    setlocale(LC_ALL, "RUS");

    float g = 6.67 * 0.00000000001;
    float m1, m2, r;
    float fp;

    puts("Введите массу первого тела");
    scanf("%f", &m1);
    puts("Введите массу второго тела");
    scanf("%f", &m2);
    puts("Введите расстояние между ними");
    scanf("%f", &r);
    fp = g * m1 * m2 / (r * r);
    printf("Сила притяжения между двумя этими телами равна %f\n", fp)
}