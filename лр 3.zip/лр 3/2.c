#include <locale.h>
#include <stdio.h>

#define D 2.54
#define P 2.32166
#define S 2.7076

voide main()

{
    int dym;
    float result1, result2, result3;

    setlocale(LC_ALL, "RUS");

    printf("Ваедите значение в двойках\n");
    scanf("%d", &dym);
    result1 = D * dym;
    result2 = P * dym;
    result3 = S * dym;
    printf("%d английских дюймов - это %.2f си\n", dym, result1);
    printf("%d испанских дюймов - это %.2f си\n", dym, result2);
    printf("%d старолитовских дюймов - это %.2f си\n", dym, result3);

    system("pause");
}