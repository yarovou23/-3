#include <stdio.h>
#include <locale.h>

void main()

{
    int num;
    int num2;
    setlocale(LC_ALL, "RUS");

    printf("Ведите целое числоо\n");
    printf("%d", &num);
    printf("Введено число %d\n", num);
    printf("Ведите целое числоо\n");
    printf("%d", &num2);
    printf("Введено число %d\n", num2);
    printf("Сумма чисел %d и %d равна %d\n", num, num2, num + num2);
    printf("Разность чисел %d и %d равна %d\n", num, num2, num - num2);
    printf("Произведение чисел %d и %d равно %d\n", num, num2, num * num2);
    printf("Частное от деления числа %d на число %d равно %d\n", num, num2, num / num2);
    printf("Остаток от деления числа %d на число %d равно %d\n", num, num2, num % num2);
}
