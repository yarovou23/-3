#include <locale.h>
#include <stdio.h>

voide main()
{
    int a, b;

    puts("Введите число a");
    scanf("%d", &a);

    puts("Введите число b");
    scanf("%d", &b);

    puts("________________________");
    puts("|a * b | a + b | a - b |");
    printf("|%d * %d | %d + %d | %d - %d |\n", a, b, a, b, a, b);
    printf("| %d | %d | %d |\n", a * b, a + b, a - b);
    
}